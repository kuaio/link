如果你可以看到本文件，说明要参考"图文教程"添加路线：

1、如果还是连接失败，请卸载360、电脑管家后重启电脑

2、请卸载其他同类的VPN代理软件，或者联系网站的客服

3、如果提示运行错误或者 .NET版本问题 ，请先下载安装

https://download.microsoft.com/download/6/E/4/6E48E8AB-DC00-419E-9704-06DD46E5F81D/NDP472-KB4054530-x86-x64-AllOS-ENU.exe